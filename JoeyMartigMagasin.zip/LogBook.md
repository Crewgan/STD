﻿# LogBook
## 05.10.2020
-Création de la structure
-Création du projet
-Création des classes
-Implémentation de la structure en C#
## 12.10.2020
-Déplacements
-Affichage
-Timer
-Caisses
-Clients
-Magasin
## 19.10.2020
-Système de queue
-Ouverture de caisses dynamique
-Refactoring
-Modification des déplacements
## 26.10.2020
-Modification "Collision" entre le client et la caisse
-Commentaires
-Suppression du timer du store
-Fermeture de caisses dynamique
-Refactoring
-Réglage de bugs