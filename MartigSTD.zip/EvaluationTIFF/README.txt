Cr�� � l'aide de visual studio 2019.
Au lancement, cliquer sur "Open file" et choisir le fichier Lenna.tiff et confirmer.
Les donn�es s'afficheront apr�s �a.